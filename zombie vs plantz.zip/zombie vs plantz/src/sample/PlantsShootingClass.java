package sample;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.awt.*;
import java.io.IOException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class PlantsShootingClass {
  //   EasyStageController ESC=new EasyStageController();
    int zombieCounter = 0;
    // HashMap<Integer, Integer> zombieHashmap = new HashMap<Integer, Integer>();
    AnchorPane anchorpane;
    Label loadlabel;
    GridPane gridpane;
    ArrayList<ImageView> bulletlist = new ArrayList<>();
    ArrayList<ImageView> plantslist = new ArrayList<>();
    ArrayList<ImageView> sunfllowerlist = new ArrayList<>();
    //ArrayList<ArrayList<Integer>> alivezombies = new ArrayList<>();
    ArrayList<ImageView> zombiesImageview = new ArrayList<>();
    ArrayList<Integer> plantsRow = new ArrayList<>();
    ArrayList<Integer> plantsColumn = new ArrayList<>();
    Timeline zombiesTimeline = new Timeline(new KeyFrame(Duration.seconds(5), e -> zombiemover()));
    Timeline zombiesMoverTimeline = new Timeline(new KeyFrame(Duration.millis(10), e -> zombiesmoverMethod()));
    Timeline plantsbulletMover = new Timeline(new KeyFrame(Duration.seconds(0.5), e -> bulletMover()));
    Timeline bulletMover = new Timeline(new KeyFrame(Duration.millis(50), e -> bulletmoverMethod()));
    Timeline addnewbullet = new Timeline(new KeyFrame(Duration.seconds(8), e -> addbulletMethod()));
    Timeline hittingCheck = new Timeline(new KeyFrame(Duration.millis(10), e -> checkHitMethod()));
    Timeline addSun = new Timeline(new KeyFrame(Duration.seconds(4), e -> addSunMethod()));
    Timeline MoverTimeline=new Timeline(new KeyFrame(Duration.millis(20),e->MoverMethod()));
  public void setLabel(Label label){
      loadlabel=label;
  }
    public void MoverMethod(){
     for (int ZCounter=0;ZCounter<zombiesImageview.size();ZCounter++){
         zombiesImageview.get(ZCounter).setLayoutX(zombiesImageview.get(ZCounter).getLayoutX()-0.5);
        /* if (zombiesImageview.get(ZCounter).getLayoutX()<70){

             Stage primaryStage = (Stage) loadlabel.getScene().getWindow();
             FXMLLoader loader2 = new FXMLLoader(getClass().getResource("losePage.fxml"));
             Parent root = null;
             try {
                 root = loader2.load();
             } catch (IOException e) {
                 e.printStackTrace();
             }
             LosePageController LP=loader2.getController();
             LP.setname(loadlabel.toString());
             primaryStage.setTitle("plants vs zombies");
             assert root != null;
             primaryStage.setScene(new Scene(root, 1300, 660));
             primaryStage.show();
             //MoverTimeline.stop();
            // addnewbullet.stop();
           //  zombiesTimeline.stop();
         }*/
     }
        for (int bulletCounter=0;bulletCounter<bulletlist.size();bulletCounter++){
            bulletlist.get(bulletCounter).setLayoutX(bulletlist.get(bulletCounter).getLayoutX()+1);

        }

        for (int i = 0; i < bulletlist.size(); i++) {
            for (int j = 0; j < zombiesImageview.size(); j++) {
                if (Math.abs((zombiesImageview.get(j).getLayoutX())-(bulletlist.get(i).getLayoutX()))<5 && zombiesImageview.get(j).getLayoutY()==bulletlist.get(i).getLayoutY()) {
                   // System.out.println("bayad nabod sheeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
                    // bulletlist.remove(i);
                    //anchorpane.getChildren().remove(zombiesImageview.get(j));
                    zombiesImageview.get(j).setLayoutY(0);
                    zombiesImageview.get(j).setLayoutX(0);
                    bulletlist.get(i).setLayoutX(1000);
                    bulletlist.get(i).setLayoutY(1000);
                    zombiesImageview.get(j).setVisible(false);
                    bulletlist.get(i).setVisible(false);

                }
            }
        }


        for (int i = 0; i <plantslist.size(); i++) {
            for (int j = 0; j < zombiesImageview.size(); j++) {
                if (Math.abs((zombiesImageview.get(j).getLayoutX())-(plantslist.get(i).getLayoutX()))<5 && zombiesImageview.get(j).getLayoutY()==plantslist.get(i).getLayoutY()) {
                    // System.out.println("bayad nabod sheeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
                    // bulletlist.remove(i);
                    //anchorpane.getChildren().remove(zombiesImageview.get(j));
                    //zombiesImageview.get(j).setLayoutY(0);
                  //  zombiesImageview.get(j).setLayoutX(0);
                    plantslist.get(i).setLayoutX(1000);
                    plantslist.get(i).setLayoutY(1000);
                   // zombiesImageview.get(j).setVisible(false);
                    plantslist.get(i).setVisible(false);
                    System.out.println("plant on zombi");
                   // ESC.setplantInvisble(plantslist.get(i));
                }
            }
        }


    }

    public void addSunMethod() {
        for (int i = 0; i < sunfllowerlist.size(); i++) {
            ImageView sun = new ImageView();
            String path = getClass().getResource("..\\sun.png").toString();
            Image im = new Image(path, 40, 40, false, false);
            sun.setImage(im);
            Random random = new Random();
            sun.setLayoutX(sunfllowerlist.get(i).getLayoutX() + 8);
            sun.setLayoutY(sunfllowerlist.get(i).getLayoutY() + 8);
            anchorpane.getChildren().add(sun);
            // random_colmn=0;
            // random_row=0;
        }
    }

    public void checkHitMethod() {
        for (int i = 0; i < bulletlist.size(); i++) {
            for (int j = 0; j < zombiesImageview.size(); j++) {
                if ((zombiesImageview.get(j).getLayoutX())==(bulletlist.get(i).getLayoutX()) && zombiesImageview.get(j).getLayoutY()==bulletlist.get(i).getLayoutY()) {
                    System.out.println("bayad nabod sheeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
                    // bulletlist.remove(i);
                    bulletlist.remove(i);
                   //  zombiesImageview.remove(j);
                    //zombiesImageview.get(j).setDisable(true);
                  //  bulletlist.get(i).setDisable(true);
                    zombiesImageview.remove(j);
                    anchorpane.getChildren().remove(bulletlist.get(i));
                    anchorpane.getChildren().remove(zombiesImageview.get(j));
                }
            }
        }


    }


    public void addbulletMethod() {
        for (int i = 0; i < plantslist.size(); i++) {
            ImageView bullet = new ImageView();
            String path = getClass().getResource("..\\bullet.png").toString();
            Image im = new Image(path, 70, 80, false, false);
            bullet.setImage(im);
            bullet.setLayoutX(plantslist.get(i).getLayoutX());
            bullet.setLayoutY(plantslist.get(i).getLayoutY());
            bulletlist.add(bullet);
            anchorpane.getChildren().add(bullet);

        }
    }

    public void bulletmoverMethod() {
        for (int i = 0; i < bulletlist.size(); i++) {
            bulletlist.get(i).setLayoutX(bulletlist.get(i).getLayoutX() + 1);
            //System.out.println("fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
        }


    }
    public void bomb(Integer X,Integer Y){
        ImageView bomb=new ImageView();
       bomb.setLayoutX(getlayoutXLocation(1, X));
       bomb.setLayoutY(getlayoutYLOcation(1, Y));
        for (int i=0;i<zombiesImageview.size();i++){
            if (Math.abs(bomb.getLayoutX()-zombiesImageview.get(i).getLayoutX())<10 || Math.abs(bomb.getLayoutY()-zombiesImageview.get(i).getLayoutY())<10){
                zombiesImageview.get(i).setLayoutY(0);
                zombiesImageview.get(i).setLayoutX(0);
                zombiesImageview.get(i).setVisible(false);
            }
        }

    }
    private void bulletMover() {
        for (int counter = 0; counter <= plantsColumn.size(); counter++) {

        }
    }


    public void plantsShootMethod() {
        for (int i = 0; i <= 8; i++) {
            for (int j = 0; j <= 3; j++) {
                //     if (aliveplants[i][j] != null) {
                String path = getClass().getResource("..\\bullet.png").toString();
                //System.out.println(path);
                ImageView bullet = new ImageView();
                Image im = new Image(path, 120, 130, false, false);
                bullet.setImage(im);
                bullet.setLayoutX(100);
                bullet.setLayoutY(60);
                //ESC.EasyStagePane.getChildren().add(bullet);
            }
        }
    }


    public void zombiesmoverMethod() {
        for (int i = 0; i < zombiesImageview.size(); i++) {
            zombiesImageview.get(i).setLayoutX(zombiesImageview.get(i).getLayoutX() - 1);
        }


    }


    public void setgridpane(GridPane pane) {
        gridpane = pane;
    }

    public void setanchorpane(AnchorPane pane) {
        anchorpane = pane;
    }

    public void setPlantinLIst(Integer X, Integer Y){
        ImageView plantlocation = new ImageView();
        plantlocation.setLayoutX(getlayoutXLocation(1, X));
        plantlocation.setLayoutY(getlayoutYLOcation(1, Y));
        plantslist.add(plantlocation);
    }

    public void zombiemover() {
      //  System.out.println("zombie mover      ZM");
        Random random = new Random();
        int max = 4;
        int randomRow = random.nextInt(max);
        int randomZombi=random.nextInt(max);
        while (randomRow == 0) {
            if (randomRow == 0) {
                randomRow = random.nextInt(max);
            }
        }
        while (randomZombi == 0) {
            if (randomZombi == 0) {
                randomZombi = random.nextInt(max);
            }
        }
        String path=null;
        ImageView zombi = new ImageView();
        if (randomZombi==1){
             path = getClass().getResource("..\\firstzombie.gif").toString();}
        if (randomZombi==2){
             path = getClass().getResource("..\\secondzombie.gif").toString();}
        if (randomZombi==3){
            path = getClass().getResource("..\\thirdzombie.gif").toString();}
        //String path = getClass().getResource("..\\zombie2.png").toString();
        Image im = new Image(path, 120, 130, false, false);
        zombi.setImage(im);



        if (randomRow == 1) {
            zombi.setLayoutX(1000);
            zombi.setLayoutY(155);
        }
        if (randomRow == 2) {

            zombi.setLayoutX(1000);
            zombi.setLayoutY(320);
        }
        if (randomRow == 3) {

            zombi.setLayoutX(1000);
            zombi.setLayoutY(500);
        }
        zombiesImageview.add(zombi);
        anchorpane.getChildren().add(zombi);
        System.out.println("bade timeline");

    }

    public void startZombiestimeline(){
        zombiesTimeline.setCycleCount(Timeline.INDEFINITE);
        zombiesTimeline.play();
        System.out.println("vasate 2 ta start timeline");
        addnewbullet.setCycleCount(Timeline.INDEFINITE);
        addnewbullet.play();
   MoverTimeline.setCycleCount(Timeline.INDEFINITE);
   MoverTimeline.play();
    }

    public double getlayoutXLocation(int gameLevel, Integer column) {
        double columnDoubleValue = 0;
        System.out.println("n                    n");
        if (gameLevel == 1) {
            if (column == 0) {
                columnDoubleValue = 170;
            }
            if (column == 1) {
                columnDoubleValue = 250;
            }
            if (column == 2) {
                columnDoubleValue = 340;
            }
            if (column == 3) {
                columnDoubleValue = 455;
            }
            if (column == 4) {
                columnDoubleValue = 545;
            }
            if (column == 5) {
                columnDoubleValue = 630;
            }
            if (column == 6) {
                columnDoubleValue = 745;
            }
            if (column == 7) {
                columnDoubleValue = 840;
            }
            if (column == 8) {
                columnDoubleValue = 970;
            }
        }
        return columnDoubleValue;
    }

    public double getlayoutYLOcation(int gameLevel, Integer row) {
        //System.out.println("yes                             yes");
        double rowDoublevalue = 0;
        if (gameLevel == 1) {
            if (row == 0) {
                rowDoublevalue = 155;
            }
            if (row == 1) {
                rowDoublevalue = 320;
            }
            if (row == 2) {
                rowDoublevalue = 500;
            }
        }
        return rowDoublevalue;
    }

    public void setsunfllowrList(Integer X, Integer Y) {
        ImageView sunfllower = new ImageView();
        sunfllower.setLayoutX(getlayoutXLocation(1, X));
        sunfllower.setLayoutY(getlayoutYLOcation(1, Y));
        sunfllowerlist.add(sunfllower);
    }
}


