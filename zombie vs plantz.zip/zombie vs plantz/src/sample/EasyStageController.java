package sample;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.beans.property.DoubleProperty;
import javafx.concurrent.Task;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.awt.*;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;

public class EasyStageController{
  //  public AnchorPane pane;
    public Label name_label;
    public AnchorPane EasyStagePane;
    public GridPane EasyStageGridPane;
    public RowConstraints zeroRow;
    public ColumnConstraints zeroColumn;
    public ImageView sunfllowerImage;
    public Label score;
    public ProgressBar Easystageprogressbar;
    public ImageView Easybackground;
    Point2D dragDistance=null;
    // ArrayList<ImageView> plantsLocationlist = new ArrayList<ImageView>();
    public ImageView plant_image;
    public ImageView image13;
    public Circle shootCircle;
    public ImageView image12;
    public ImageView image11;
    public ImageView image23;
    boolean plantsAlive=true;
    Timeline shootingTimeLine;
    int plantChooser=0;
    int newScore=1000;
    double progress;
    String playersfilename;
    ArrayList<ImageView> zombiesImageview=new ArrayList<>();
    ArrayList<Integer> plantsLocationslist=new ArrayList<Integer>();
   // Timeline zombiesMoverTimeline = new Timeline(new KeyFrame(Duration.seconds(1), e -> zombiesmoverMethod()));
  //  Timeline zombieTimeline=new Timeline(new KeyFrame(Duration.seconds(1),e->zombiesComing()));
   // PlantsShootingClass PSC=new PlantsShootingClass();
    Timeline progresstimeline=new Timeline(new KeyFrame(Duration.seconds(1),e->progressbar()));
    GameUiStuffsClass PSC=new GameUiStuffsClass();
    public void setName_label(String name_label1) {
       name_label.setText(name_label1);
       PSC.setLabel(name_label);
    }
  public void setplayersfilename(String a){
        playersfilename=a;
  }
    public void progressbar(){
        progress+=0.002;
        Easystageprogressbar.setProgress(progress);

        File file=new File("D:\\computer engineering\\java game\\zombie vs plantz\\"+playersfilename);
        file.delete();
        try {
            FileWriter pw1 = new FileWriter(playersfilename);
            pw1.write("last record:"+Easystageprogressbar.getProgress());
            pw1.close();
            System.out.println("done");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }



    public void StartzombiesTimeline(){
        System.out.println("start zombie time line");
       // zombieTimeline.setCycleCount(Timeline.INDEFINITE);
      //  zombieTimeline.play();
      //  PSC.start();
    }
    public void zombiesComing() {
        System.out.println("zombi is coming timeline method");
        Random random=new Random();
        int max=4;

        int randomRow=random.nextInt(max);
        while (randomRow==0){
        if (randomRow==0){
            randomRow=random.nextInt(max);
        }}
       // System.out.println("radif"+randomRow);
        String path=getClass().getResource("..\\zombie2.png").toString();
        //System.out.println(path);
        ImageView zombi=new ImageView();
        Image im=new Image(path,120,130,false,false);
        zombi.setImage(im);
        if (randomRow==1){
            //String path=getClass().getResource("..\\zombie2.png").toString();
            //System.out.println(path);
           // ImageView zombi=new ImageView();
           // Image im=new Image(path,120,130,false,false);
           // zombi.setImage(im);
            zombi.setLayoutX(1000);
            zombi.setLayoutY(155);
         //  EasyStagePane.getChildren().add(zombi);
           // EasyStagePane.getChildren().add(zombi);
        }
        if (randomRow==2){
         zombi.setLayoutX(1000);
          zombi.setLayoutY(305);
        }
        if (randomRow==3){
          zombi.setLayoutX(1000);
          zombi.setLayoutY(500);
        }

       zombiesImageview.add(zombi);
    //    EasyStagePane.getChildren().add(zombi);
    }

    public void zombiesmoverMethod() {
        //  int counter=1;
        System.out.println("into for              IF");
        while (zombiesImageview.size()>0){

            for (int counter=1;counter<zombiesImageview.size();counter++){
                System.out.println("into for              IF");
                zombiesImageview.get(counter).setLayoutX(zombiesImageview.get(counter).getLayoutX()-3);
            }
        }





    }

    public void starttimeline(){
        PSC.setanchorpane(EasyStagePane);
        PSC.setgridpane(EasyStageGridPane);
        PSC.startZombiestimeline();
        PSC.setgamelevel(1);
        progresstimeline.setCycleCount(Timeline.INDEFINITE);
        progresstimeline.play();
    }
    public void handleDragDetection(MouseEvent mouseEvent) {
        Dragboard db = plant_image.startDragAndDrop(TransferMode.ANY);
        ClipboardContent cb=new ClipboardContent();
        cb.putImage(plant_image.getImage());
        db.setContent(cb);
        mouseEvent.consume();
        //  while (plantsLocationslist.size()>0){
        // shootingTimeLine=new Timeline(new KeyFrame(Duration.millis(2),this::shootingMethod));
        //shootingTimeLine.play();}
    }

    public void handlegridpanemousepressed(MouseEvent mouseEvent) {
        Node source=(Node) mouseEvent.getSource();
        //System.out.println(EasyStageGridPane.getColumnCount()+"         "+EasyStageGridPane.getRowCount()+"\n");
       //Node source=(Node) mouseEvent.getSource();
        Integer colIndex= EasyStageGridPane.getColumnIndex(source);
        Integer rowIndex= EasyStageGridPane.getRowIndex(source);
     //  PSC.plantsInThread(colIndex,rowIndex);
       // System.out.println(colIndex+"    "+rowIndex+"\n");
        String path;

       // PSC.plantsInThread(colIndex,rowIndex);
        if(colIndex == null){
            colIndex=0;}
        if(rowIndex == null){
            rowIndex=0;}
        System.out.println(colIndex+"    "+rowIndex+"\n");
        if(plantChooser==1 && newScore>=100){
            newScore=newScore-100;
            path =getClass().getResource("..\\plantsgif.gif").toString();
            //System.out.println(path);
           // dropimage(EasyStageGridPane,colIndex,rowIndex,path);
            plantChooser=0;
            PSC.setPlantinLIst(1,colIndex,rowIndex);
        }
        if (plantChooser==2 && newScore>=50){
            newScore=newScore-50;
            path =getClass().getResource("..\\sunflowergif.gif").toString();

            plantChooser=0;
            PSC.setsunfllowrList(1,colIndex,rowIndex);
        }
        if (plantChooser==3 && newScore>=50){
            newScore=newScore-50;

            plantChooser=0;
            PSC.bomb(1,colIndex,rowIndex);
        }
        score.setText(String.valueOf(newScore));
    }

     public void dropimage(GridPane stagegridpane,Integer colIndex,Integer rowIndex,String path){
        ImageView img=new ImageView();
        Image im=new Image(path,90,90,false,false);
        img.setImage(im);
        stagegridpane.add(img,colIndex,rowIndex,1,1);

     }






    public void handlePlantonMouseClick(MouseEvent mouseEvent) {
        plantChooser=1;
    }


    public void handleSunfllowerClick(MouseEvent mouseEvent) {
        plantChooser=2;
    }

    public void potatoOnClick(MouseEvent mouseEvent) {plantChooser=3; }
}

