package sample;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

public class Controller {
    public Label wellcome_label;
    public  Label incorrect_label;
    public TextField player_name;
    public TextField player_pass;
    public MenuButton btnSetDifficulty;
    public MenuItem daymode;
    public MenuItem nightmode;
    int gameLevel;
    String game_level=null;
    MediaPlayer mediaplayer;
    public void onaction_createAcc(ActionEvent actionEvent) throws IOException {
        Stage primaryStage = (Stage) wellcome_label.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("CreateAccount.fxml"));
        primaryStage.setTitle("plants vs zombies");
        primaryStage.setScene(new Scene(root, 1160, 660));
        primaryStage.show();


    }

    public void onclick_login(ActionEvent actionEvent) throws IOException{
        String playersfilename =player_name.getText()+player_pass.getText();
        File fileAliveTest=new File("D:\\computer engineering\\java game\\zombie vs plantz\\"+playersfilename);
        if(fileAliveTest.exists() && game_level=="easy"){
            Stage primaryStage = (Stage) wellcome_label.getScene().getWindow();
           // Parent root = FXMLLoader.load(getClass().getResource("EasyStage.fxml"));
            FXMLLoader loader2 = new FXMLLoader(getClass().getResource("EasyStage.fxml"));
            Parent root = loader2.load();
            EasyStageController Es=loader2.getController();

            Es.setName_label(player_name.getText().toString()+"  is  playing");
            Es.starttimeline();
            Es.setplayersfilename(playersfilename);
            primaryStage.setTitle("plants vs zombies");
            primaryStage.setScene(new Scene(root, 1110, 625));
            primaryStage.show();
        }else if (fileAliveTest.exists() && game_level=="medium"){
            Stage primaryStage = (Stage) wellcome_label.getScene().getWindow();
            // Parent root = FXMLLoader.load(getClass().getResource("EasyStage.fxml"));
            FXMLLoader loader2 = new FXMLLoader(getClass().getResource("mediumStage.fxml"));
            Parent root = loader2.load();
            mediumstageController MD=loader2.getController();
            MD.starttimeline();
            MD.setplayersfilename(playersfilename);
            primaryStage.setTitle("plants vs zombies");
            primaryStage.setScene(new Scene(root, 1100, 625));
            primaryStage.show();
        }
        else if(fileAliveTest.exists() && game_level=="hard"){
            Stage primaryStage = (Stage) wellcome_label.getScene().getWindow();
            // Parent root = FXMLLoader.load(getClass().getResource("EasyStage.fxml"));
            FXMLLoader loader2 = new FXMLLoader(getClass().getResource("HardStage.fxml"));
            Parent root = loader2.load();
            HardStageController HS=loader2.getController();
            HS.starttimeline();
            HS.setplayersfilename(playersfilename);
           // Es.setName_label(player_name.getText().toString()+"  is  playing");
            //Es.starttimeline();

            primaryStage.setTitle("plants vs zombies");
            primaryStage.setScene(new Scene(root, 1110, 625));
            primaryStage.show();




        }
        else{incorrect_label.setText("Your information for play is incomplete or incorrect");}
    }

    public void easyStage(ActionEvent actionEvent) {
        game_level="easy";
        btnSetDifficulty.setText("Easy");

    }

    public void mediumStage(ActionEvent actionEvent) {
        game_level="medium";
        btnSetDifficulty.setText("Medium");

    }

    public void hardStage(ActionEvent actionEvent) {
        game_level="hard";
        btnSetDifficulty.setText("Hard");

    }

}
