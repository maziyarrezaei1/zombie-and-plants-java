package sample;
import java.io.IOException;
import java.io.File;
import java.io.FileWriter;
import java.util.Date;
public class FileCreator {

    public void create_file(String playerFileName) {

        try {
            File players = new File("players_info.txt");
            if (players.createNewFile()) {
                System.out.println("File created: ");
            } else {
                System.out.println("File already exists.");
            }
            FileWriter playersfile = new FileWriter(playerFileName);
            //  playersfile.write("password:" + password);
            playersfile.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }


    }




}
