package sample;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.awt.*;
import java.io.IOException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class GameUiStuffsClass{
     //  EasyStageController ESC=new EasyStageController();
    int zombieCounter = 0;
    int gamelevel;
    // HashMap<Integer, Integer> zombieHashmap = new HashMap<Integer, Integer>();
    AnchorPane anchorpane;
    Label loadlabel;
    GridPane gridpane;
    ArrayList<ImageView> bombs=new ArrayList<>();
    ArrayList<ImageView> bulletlist = new ArrayList<>();
    ArrayList<ImageView> plantslist = new ArrayList<>();
    ArrayList<ImageView> sunfllowerlist = new ArrayList<>();
    ArrayList<ImageView> sunslist=new ArrayList<>();
    //ArrayList<ArrayList<Integer>> alivezombies = new ArrayList<>();
    ArrayList<ImageView> zombiesImageview = new ArrayList<>();
    ArrayList<Integer> plantsRow = new ArrayList<>();
    ArrayList<Integer> plantsColumn = new ArrayList<>();
    Timeline zombiesTimeline = new Timeline(new KeyFrame(Duration.seconds(5), e -> zombiemover()));
    Timeline zombiesMoverTimeline = new Timeline(new KeyFrame(Duration.millis(10), e -> zombiesmoverMethod()));
    Timeline plantsbulletMover = new Timeline(new KeyFrame(Duration.seconds(0.5), e -> bulletMover()));
    Timeline bulletMover = new Timeline(new KeyFrame(Duration.millis(50), e -> bulletmoverMethod()));
    Timeline addnewbullet = new Timeline(new KeyFrame(Duration.seconds(8), e -> addbulletMethod()));
    Timeline hittingCheck = new Timeline(new KeyFrame(Duration.millis(10), e -> checkHitMethod()));
    Timeline addSun = new Timeline(new KeyFrame(Duration.seconds(4), e -> addSunMethod()));
    Timeline MoverTimeline=new Timeline(new KeyFrame(Duration.millis(20),e->MoverMethod()));
    Timeline musicplayer=new Timeline(new KeyFrame(Duration.seconds(45),e->musicmetod()));
    Timeline removebomb=new Timeline(new KeyFrame(Duration.seconds(5),e->{
        for (int i=0;i<bombs.size();i++){
            bombs.get(i).setVisible(false);
        }
    }));

    public void musicmetod(){
        AudioClip note=new AudioClip(getClass().getResource("..\\backgroundmusic.mp3").toString());
        note.play();
    }

    public void setLabel(Label label){
        loadlabel=label;
    }
    public void MoverMethod(){
        for (int ZCounter=0;ZCounter<zombiesImageview.size();ZCounter++){
            zombiesImageview.get(ZCounter).setLayoutX(zombiesImageview.get(ZCounter).getLayoutX()-0.5);
         if (zombiesImageview.get(ZCounter).getLayoutX()<100){
             Stage primaryStage = (Stage) loadlabel.getScene().getWindow();
             // Parent root = FXMLLoader.load(getClass().getResource("EasyStage.fxml"));
             FXMLLoader loader2 = new FXMLLoader(getClass().getResource("losePage.fxml"));
             Parent root = null;
             try {
                 root = loader2.load();
             } catch (IOException e) {
                 e.printStackTrace();
             }
             //   EasyStageController Es=loader2.getController();

             //Es.setName_label(player_name.getText().toString()+"  is  playing");
           //  Es.starttimeline();
            // Es.setplayersfilename(playersfilename);

             primaryStage.setTitle("plants vs zombies");
             assert root != null;
             primaryStage.setScene(new Scene(root, 1160, 670));
             primaryStage.show();
             MoverTimeline.stop();

         }
        }
        for (int bulletCounter=0;bulletCounter<bulletlist.size();bulletCounter++){
            bulletlist.get(bulletCounter).setLayoutX(bulletlist.get(bulletCounter).getLayoutX()+1);

        }

        for (int i = 0; i < bulletlist.size(); i++) {
            for (int j = 0; j < zombiesImageview.size(); j++) {
                if (Math.abs((zombiesImageview.get(j).getLayoutX())-(bulletlist.get(i).getLayoutX()))<5 && zombiesImageview.get(j).getLayoutY()==bulletlist.get(i).getLayoutY()) {
                    // System.out.println("bayad nabod sheeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
                    // bulletlist.remove(i);
                    //anchorpane.getChildren().remove(zombiesImageview.get(j));
                    zombiesImageview.get(j).setLayoutY(5000);
                    zombiesImageview.get(j).setLayoutX(5000);
                    bulletlist.get(i).setLayoutX(0);
                    bulletlist.get(i).setLayoutY(0);
                    zombiesImageview.get(j).setVisible(false);
                    bulletlist.get(i).setVisible(false);

                }
            }
        }



        for (int i = 0; i <plantslist.size(); i++) {
            for (int j = 0; j < zombiesImageview.size(); j++) {
                if (Math.abs((zombiesImageview.get(j).getLayoutX())-(plantslist.get(i).getLayoutX()))<5 && zombiesImageview.get(j).getLayoutY()==plantslist.get(i).getLayoutY()) {
                    // System.out.println("bayad nabod sheeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
                    // bulletlist.remove(i);
                    //anchorpane.getChildren().remove(zombiesImageview.get(j));
                    //zombiesImageview.get(j).setLayoutY(0);
                    //  zombiesImageview.get(j).setLayoutX(0);
                    plantslist.get(i).setLayoutX(1000);
                    plantslist.get(i).setLayoutY(1000);
                    // zombiesImageview.get(j).setVisible(false);
                    plantslist.get(i).setVisible(false);
                    System.out.println("plant on zombi");
                    // ESC.setplantInvisble(plantslist.get(i));
                }
            }
        }
        for (int i = 0; i <sunfllowerlist.size(); i++) {
            for (int j = 0; j < zombiesImageview.size(); j++) {
                if (Math.abs((zombiesImageview.get(j).getLayoutX())-(sunfllowerlist.get(i).getLayoutX()))<5 && zombiesImageview.get(j).getLayoutY()==sunfllowerlist.get(i).getLayoutY()) {
                    // System.out.println("bayad nabod sheeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
                    // bulletlist.remove(i);
                    //anchorpane.getChildren().remove(zombiesImageview.get(j));
                    //zombiesImageview.get(j).setLayoutY(0);
                    //  zombiesImageview.get(j).setLayoutX(0);
                    sunfllowerlist.get(i).setLayoutX(1000);
                    sunfllowerlist.get(i).setLayoutY(1000);
                    // zombiesImageview.get(j).setVisible(false);
                    sunslist.get(i).setVisible(false);
                    sunfllowerlist.get(i).setVisible(false);
                    System.out.println("plant on zombi");
                    // ESC.setplantInvisble(plantslist.get(i));
                }
            }
        }

    }

    public void addSunMethod() {
        for (int i = 0; i < sunfllowerlist.size(); i++) {
            ImageView sun = new ImageView();
            String path = getClass().getResource("..\\sun.png").toString();
            Image im = new Image(path, 40, 40, false, false);
            sun.setImage(im);
            Random random = new Random();
            sun.setLayoutX(sunfllowerlist.get(i).getLayoutX() + 8);
            sun.setLayoutY(sunfllowerlist.get(i).getLayoutY() + 8);
            anchorpane.getChildren().add(sun);
            // random_colmn=0;
            // random_row=0;
        }
    }

    public void checkHitMethod() {
        for (int i = 0; i < bulletlist.size(); i++) {
            for (int j = 0; j < zombiesImageview.size(); j++) {
                if ((zombiesImageview.get(j).getLayoutX())==(bulletlist.get(i).getLayoutX()) && zombiesImageview.get(j).getLayoutY()==bulletlist.get(i).getLayoutY()) {
                    System.out.println("bayad nabod sheeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
                    // bulletlist.remove(i);
                    bulletlist.remove(i);
                    //  zombiesImageview.remove(j);
                    //zombiesImageview.get(j).setDisable(true);
                    //  bulletlist.get(i).setDisable(true);
                    zombiesImageview.remove(j);
                    anchorpane.getChildren().remove(bulletlist.get(i));
                    anchorpane.getChildren().remove(zombiesImageview.get(j));
                }
            }
        }


    }


    public void addbulletMethod() {
        for (int i = 0; i < plantslist.size(); i++) {
            ImageView bullet = new ImageView();
            String path = getClass().getResource("..\\bullet.png").toString();
            Image im = new Image(path, 70, 80, false, false);
            bullet.setImage(im);
            bullet.setLayoutX(plantslist.get(i).getLayoutX());
            bullet.setLayoutY(plantslist.get(i).getLayoutY());
            bulletlist.add(bullet);
            anchorpane.getChildren().add(bullet);

        }
    }

    public void bulletmoverMethod() {
        for (int i = 0; i < bulletlist.size(); i++) {
            bulletlist.get(i).setLayoutX(bulletlist.get(i).getLayoutX() + 1);
            //System.out.println("fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
        }


    }
    public void bomb(int gamelevel,Integer X,Integer Y){
        String path =getClass().getResource("..\\CherryBomb.gif").toString();
        ImageView bomb=new ImageView();
        //ImageView img=new ImageView();
        Image im=new Image(path,90,90,false,false);
        bomb.setImage(im);
        if (gamelevel==1){
        bomb.setLayoutX(getlayoutXLocation(1, X));
        bomb.setLayoutY(getlayoutYLOcation(1, Y));}
        if (gamelevel==2){
            bomb.setLayoutX(getlayoutXLocation(2, X));
            bomb.setLayoutY(getlayoutYLOcation(2, Y));
        }
        if (gamelevel==3){
            bomb.setLayoutX(getlayoutXLocation(3, X));
            bomb.setLayoutY(getlayoutYLOcation(3, Y));
        }
        anchorpane.getChildren().add(bomb);
        bombs.add(bomb);
        for (int i=0;i<zombiesImageview.size();i++){
            if (Math.abs(bomb.getLayoutX()-zombiesImageview.get(i).getLayoutX())<10 || Math.abs(bomb.getLayoutY()-zombiesImageview.get(i).getLayoutY())<200){
                zombiesImageview.get(i).setLayoutY(2000);
                zombiesImageview.get(i).setLayoutX(2000);
                zombiesImageview.get(i).setVisible(false);
            }
        }
      removebomb.setCycleCount(1);
        removebomb.play();
       // bomb.setVisible(false);
    }
    private void bulletMover() {
        for (int counter = 0; counter <= plantsColumn.size(); counter++) {

        }
    }


    public void plantsShootMethod() {
        for (int i = 0; i <= 8; i++) {
            for (int j = 0; j <= 3; j++) {
                //     if (aliveplants[i][j] != null) {
                String path = getClass().getResource("..\\bullet.png").toString();
                //System.out.println(path);
                ImageView bullet = new ImageView();
                Image im = new Image(path, 120, 130, false, false);
                bullet.setImage(im);
                bullet.setLayoutX(100);
                bullet.setLayoutY(60);
                //ESC.EasyStagePane.getChildren().add(bullet);
            }
        }
    }
 public void setgamelevel(int level){
        gamelevel=level;
 }

    public void zombiesmoverMethod() {
        for (int i = 0; i < zombiesImageview.size(); i++) {
            zombiesImageview.get(i).setLayoutX(zombiesImageview.get(i).getLayoutX() - 1);
        }


    }


    public void setgridpane(GridPane pane) {
        gridpane = pane;
    }

    public void setanchorpane(AnchorPane pane) {
        anchorpane = pane;
    }

    public void setPlantinLIst(int gamelevel,Integer X, Integer Y){
      //  ImageView img=new ImageView();
     //   Image im=new Image(path,90,90,false,false);
      //  img.setImage(im);
        if (gamelevel==1){
        String path =getClass().getResource("..\\plantsgif.gif").toString();
        ImageView plantlocation = new ImageView();
        Image im=new Image(path,90,90,false,false);
        plantlocation.setImage(im);
        plantlocation.setLayoutX(getlayoutXLocation(1, X));
        plantlocation.setLayoutY(getlayoutYLOcation(1, Y));
        plantslist.add(plantlocation);
        anchorpane.getChildren().add(plantlocation);
    }if (gamelevel==2){
            String path =getClass().getResource("..\\plantsgif.gif").toString();
            ImageView plantlocation = new ImageView();
            Image im=new Image(path,90,90,false,false);
            plantlocation.setImage(im);
            plantlocation.setLayoutX(getlayoutXLocation(2, X));
            plantlocation.setLayoutY(getlayoutYLOcation(2, Y));
            plantslist.add(plantlocation);
            anchorpane.getChildren().add(plantlocation);
        }
        if (gamelevel==3){
            String path =getClass().getResource("..\\plantsgif.gif").toString();
            ImageView plantlocation = new ImageView();
            Image im=new Image(path,90,90,false,false);
            plantlocation.setImage(im);
            plantlocation.setLayoutX(getlayoutXLocation(3, X));
            plantlocation.setLayoutY(getlayoutYLOcation(3, Y));
            plantslist.add(plantlocation);
            anchorpane.getChildren().add(plantlocation);
        }









    }

    public void zombiemover() {
        //  System.out.println("zombie mover      ZM");
        Random random = new Random();
        int zombiemax=2;
        int max = 4;
        int randomRow = random.nextInt(max);
        int randomZombi=random.nextInt(zombiemax);
        while (randomRow == 0) {
            if (randomRow == 0) {
                randomRow = random.nextInt(max);
            }
        }
        while (randomZombi == 0) {
            if (randomZombi == 0) {
                randomZombi = random.nextInt(max);
            }
        }
        String path=getClass().getResource("..\\thirdzombie.gif").toString();
        ImageView zombi = new ImageView();

            //path = getClass().getResource("..\\firstzombie.gif").toString();
          //  path = getClass().getResource("..\\thirdzombie.gif").toString();}
        if (randomZombi==2){
            path = getClass().getResource("..\\secondzombie.gif").toString();}
        //String path = getClass().getResource("..\\zombie2.png").toString();
        Image im = new Image(path, 100, 100, false, false);
        zombi.setImage(im);


       if (gamelevel==1){
        if (randomRow == 1) {
            zombi.setLayoutX(1000);
            zombi.setLayoutY(170);
        }
        if (randomRow == 2) {

            zombi.setLayoutX(1000);
            zombi.setLayoutY(320);
        }
        if (randomRow == 3) {

            zombi.setLayoutX(1000);
            zombi.setLayoutY(500);
        }
       }if (gamelevel==2){
           int max3=4;
           randomRow=random.nextInt(max3);
            if (randomRow==0){
                zombi.setLayoutX(1010);
                zombi.setLayoutY(85);
            }
            if (randomRow==1){
                zombi.setLayoutX(1010);
                zombi.setLayoutY(150);
            }
            if (randomRow==2){
                zombi.setLayoutX(1010);
                zombi.setLayoutY(475);
            }
            if (randomRow==3){
                zombi.setLayoutX(1010);
                zombi.setLayoutY(540);

            }
        }
       if (gamelevel==3){
           int max2=5;
           randomRow=random.nextInt(max2);
           if (randomRow==0){
               zombi.setLayoutX(1010);
               zombi.setLayoutY(40);
           }
           if (randomRow==1){
               zombi.setLayoutX(1010);
               zombi.setLayoutY(140);
           }
           if (randomRow==2){
               zombi.setLayoutX(1010);
               zombi.setLayoutY(240);
           }
           if (randomRow==3){
               zombi.setLayoutX(1010);
               zombi.setLayoutY(375);

           }
           if (randomRow==4){
               zombi.setLayoutX(1010);
               zombi.setLayoutY(470);
           }}




                zombiesImageview.add(zombi);
                anchorpane.getChildren().add(zombi);
                System.out.println("bade timeline");




    }


    public void startZombiestimeline(){
        musicmetod();
        zombiesTimeline.setCycleCount(Timeline.INDEFINITE);
        zombiesTimeline.play();
        System.out.println("vasate 2 ta start timeline");
        addnewbullet.setCycleCount(Timeline.INDEFINITE);
        addnewbullet.play();
        MoverTimeline.setCycleCount(Timeline.INDEFINITE);
        MoverTimeline.play();
        musicplayer.setCycleCount(Timeline.INDEFINITE);
        musicplayer.play();
    }

    public double getlayoutXLocation(int gameLevel, Integer column) {
        double columnDoubleValue = 0;
        System.out.println("n                    n");
        if (gameLevel == 1) {
            if (column == 0) {
                columnDoubleValue = 170;
            }
            if (column == 1) {
                columnDoubleValue = 250;
            }
            if (column == 2) {
                columnDoubleValue = 340;
            }
            if (column == 3) {
                columnDoubleValue = 455;
            }
            if (column == 4) {
                columnDoubleValue = 545;
            }
            if (column == 5) {
                columnDoubleValue = 630;
            }
            if (column == 6) {
                columnDoubleValue = 755;
            }
            if (column == 7) {
                columnDoubleValue = 840;
            }
            if (column == 8) {
                columnDoubleValue = 970;
            }
        }if (gameLevel==2){
            if (column == 0) {
                columnDoubleValue = 220;
            }
            if (column == 1) {
                columnDoubleValue = 290;
            }
            if (column == 2) {
                columnDoubleValue = 360;
            }
            if (column == 3) {
                columnDoubleValue = 485;
            }
            if (column == 4) {
                columnDoubleValue = 550;
            }
            if (column == 5) {
                columnDoubleValue = 610;
            }
            if (column == 6) {
                columnDoubleValue = 680;
            }
            if (column == 7) {
                columnDoubleValue = 770;
            }
            if (column == 8) {
                columnDoubleValue = 925;
            }


        }
        if (gameLevel==3){
            if (column == 0) {
                columnDoubleValue = 260;
            }
            if (column == 1) {
                columnDoubleValue = 345;
            }
            if (column == 2) {
                columnDoubleValue = 425;
            }
            if (column == 3) {
                columnDoubleValue = 515;
            }
            if (column == 4) {
                columnDoubleValue = 625;
            }
            if (column == 5) {
                columnDoubleValue = 725;
            }
            if (column == 6) {
                columnDoubleValue = 835;
            }
            if (column == 7) {
                columnDoubleValue = 935;
            }
            if (column == 8) {
                columnDoubleValue = 955;

        }}
        return columnDoubleValue;
    }

    public double getlayoutYLOcation(int gameLevel, Integer row) {
        //System.out.println("yes                             yes");
        double rowDoublevalue = 0;
        if (gameLevel == 1) {
            if (row == 0) {
                rowDoublevalue = 170;
            }
            if (row == 1) {
                rowDoublevalue = 320;
            }
            if (row == 2) {
                rowDoublevalue = 500;
            }
        }if (gameLevel==2){
            if (row == 0) {
                rowDoublevalue = 85;
            }
            if (row == 1) {
                rowDoublevalue = 150;
            }
            if (row == 3) {
                rowDoublevalue =475;
            }if (row==4){
                rowDoublevalue=540;
            }
        }
        if (gameLevel==3){
            if (row == 0) {
                rowDoublevalue = 40;
            }
            if (row == 1) {
                rowDoublevalue = 140;
            }
            if (row == 2) {
                rowDoublevalue = 240;
        }
            if (row==3){
                rowDoublevalue=375;
            }
            if (row==4){
                rowDoublevalue=470;
            }




        }
        return rowDoublevalue;
    }

    public void setsunfllowrList(int gamelevel,Integer X, Integer Y) {
        String path =getClass().getResource("..\\sunflowergif.gif").toString();
        ImageView sunfllower = new ImageView();
        Image im=new Image(path,90,90,false,false);
        sunfllower.setImage(im);
        if (gamelevel==1){
        sunfllower.setLayoutX(getlayoutXLocation(1, X));
        sunfllower.setLayoutY(getlayoutYLOcation(1, Y));}
        if (gamelevel==2){
            sunfllower.setLayoutX(getlayoutXLocation(2, X));
            sunfllower.setLayoutY(getlayoutYLOcation(2, Y));
        }
        if (gamelevel==3){
            sunfllower.setLayoutX(getlayoutXLocation(3, X));
            sunfllower.setLayoutY(getlayoutYLOcation(3, Y));
        }
        sunfllowerlist.add(sunfllower);
        anchorpane.getChildren().add(sunfllower);
        Timeline addsun=new Timeline(new KeyFrame(Duration.seconds(8),e->{
            ImageView sun = new ImageView();
            String path1 = getClass().getResource("..\\sun.png").toString();
            Image im1 = new Image(path1, 40, 40, false, false);
            sun.setImage(im1);
            sun.setLayoutX(sunfllower.getLayoutX() + 8);
            sun.setLayoutY(sunfllower.getLayoutY() + 8);
            sunslist.add(sun);
            anchorpane.getChildren().add(sun);
        }));
        addsun.setCycleCount(1);
        addsun.play();
    }
}


