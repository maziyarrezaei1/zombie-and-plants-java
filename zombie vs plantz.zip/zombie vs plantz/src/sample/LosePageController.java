package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class LosePageController {

    public Label namelabel;
    public Button returnButton;
    public Label loseLabel;

    public void returnOnclick(ActionEvent actionEvent) throws IOException {
        Stage primaryStage = (Stage) loseLabel.getScene().getWindow();
        // Parent root = FXMLLoader.load(getClass().getResource("EasyStage.fxml"));
        FXMLLoader loader2 = new FXMLLoader(getClass().getResource("sample.fxml"));
        Parent root = loader2.load();
        //  Es.StartzombiesTimeline();
        //  PlantsShootingClass ps=new PlantsShootingClass();
        // ps.startZombiestimeline();
        primaryStage.setTitle("plants vs zombies");
        primaryStage.setScene(new Scene(root, 1160, 660));
        primaryStage.show();
    }
   // public void setname(String name){
       // namelabel.setText(name);
   // }

}
