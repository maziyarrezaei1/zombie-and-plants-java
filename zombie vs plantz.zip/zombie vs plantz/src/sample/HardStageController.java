package sample;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.util.Duration;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class HardStageController {
    public ImageView peashooterCard;
    public ImageView sunfllowerCard;
    public ImageView bombCard;
    public GridPane HardstageGridpane;
    public Label scoreLabel;
    public AnchorPane Hardanchorpane;
    public ProgressBar stageprogressbar;
    int characterChooser;
    int newScore=2000;
    double progress;
    String playersfilename;
    GameUiStuffsClass PSC=new GameUiStuffsClass();
    Timeline progresstimeline=new Timeline(new KeyFrame(Duration.seconds(1), e->progressbar()));
    public void peashooterOnClick(MouseEvent mouseEvent) {characterChooser=1;
    }

    public void sunfllowerOnClick(MouseEvent mouseEvent) {characterChooser=2;
    }

    public void bombOnClick(MouseEvent mouseEvent) {characterChooser=3;
    }
    public void handlegridpanemousepressed(MouseEvent mouseEvent){
        Node source=(Node) mouseEvent.getSource();
        //System.out.println(EasyStageGridPane.getColumnCount()+"         "+EasyStageGridPane.getRowCount()+"\n");
        //Node source=(Node) mouseEvent.getSource();
        Integer colIndex= HardstageGridpane.getColumnIndex(source);
        Integer rowIndex= HardstageGridpane.getRowIndex(source);
        //  PSC.plantsInThread(colIndex,rowIndex);
        // System.out.println(colIndex+"    "+rowIndex+"\n");
        String path;

        // PSC.plantsInThread(colIndex,rowIndex);
        if(colIndex == null){
            colIndex=0;}
        if(rowIndex == null){
            rowIndex=0;}
        System.out.println(colIndex+"    "+rowIndex+"\n");
        if(characterChooser==1 && newScore>=100){
            newScore=newScore-100;
          //  path =getClass().getResource("..\\plantsgif.gif").toString();
            //System.out.println(path);
          //  dropimage(HardstageGridpane,colIndex,rowIndex,path);
            characterChooser=0;
            PSC.setPlantinLIst(3,colIndex,rowIndex);
        }
        if (characterChooser==2 && newScore>=50){
            newScore=newScore-50;
            path =getClass().getResource("..\\sunflowergif.gif").toString();
            //System.out.println(path);
          //  dropimage(HardstageGridpane,colIndex,rowIndex,path);
            characterChooser=0;
            PSC.setsunfllowrList(3,colIndex,rowIndex);
        }
        if (characterChooser==3 && newScore>=50){
            newScore=newScore-50;
            path =getClass().getResource("..\\potatogif.gif").toString();

            PSC.bomb(3,colIndex,rowIndex);
        }
        scoreLabel.setText(String.valueOf("score: "+newScore));
    }

    public void dropimage(GridPane stagegridpane, Integer colIndex, Integer rowIndex, String path){
        ImageView img=new ImageView();
        Image im=new Image(path,90,90,false,false);
        img.setImage(im);
        stagegridpane.add(img,colIndex,rowIndex,1,1);

    }

    public void starttimeline(){
        PSC.setanchorpane(Hardanchorpane);
        PSC.setgridpane(HardstageGridpane);
        PSC.startZombiestimeline();
        PSC.setgamelevel(3);
        PSC.setLabel(scoreLabel);
        progresstimeline.setCycleCount(Timeline.INDEFINITE);
        progresstimeline.play();

    }
    public void progressbar(){
        progress+=0.002;
        stageprogressbar.setProgress(progress);

        File file=new File("D:\\computer engineering\\java game\\zombie vs plantz\\"+playersfilename);
        file.delete();
        try {
            FileWriter pw1 = new FileWriter(playersfilename);
            pw1.write("last record:"+stageprogressbar.getProgress());
            pw1.close();
            //System.out.println("done");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    public void setplayersfilename(String a){
        playersfilename=a;
    }

}

