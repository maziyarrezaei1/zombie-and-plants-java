package sample;

import javafx.animation.Timeline;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

public class mediumstageController {
    public ImageView sunfllowerCard;
    public Label score;
    public GridPane StageGridPane;
    public AnchorPane mediumanchorpane;
    int  newScore=1500;
    int plantChooser;
    String filename;
    GameUiStuffsClass PSC=new GameUiStuffsClass();
    public void bombOnclick(MouseEvent mouseEvent) {
        plantChooser=3;
    }

    public void plantsOnclick(MouseEvent mouseEvent) {
    plantChooser=1;}

    public void sunfllowerOnClick(MouseEvent mouseEvent) {
    plantChooser=2;}

    public void handlegridpanemousepressed(MouseEvent mouseEvent) {
        Node source=(Node) mouseEvent.getSource();
        //System.out.println(EasyStageGridPane.getColumnCount()+"         "+EasyStageGridPane.getRowCount()+"\n");
        //Node source=(Node) mouseEvent.getSource();
        Integer colIndex= StageGridPane.getColumnIndex(source);
        Integer rowIndex= StageGridPane.getRowIndex(source);
        //  PSC.plantsInThread(colIndex,rowIndex);
        // System.out.println(colIndex+"    "+rowIndex+"\n");
        String path;

        // PSC.plantsInThread(colIndex,rowIndex);
        if(colIndex == null){
            colIndex=0;}
        if(rowIndex == null){
            rowIndex=0;}
        System.out.println(colIndex+"    "+rowIndex+"\n");
        if(plantChooser==1 && newScore>=100){
            newScore=newScore-100;
            path =getClass().getResource("..\\plantsgif.gif").toString();
            //System.out.println(path);
            // dropimage(EasyStageGridPane,colIndex,rowIndex,path);
            plantChooser=0;
            PSC.setPlantinLIst(2,colIndex,rowIndex);
        }
        if (plantChooser==2 && newScore>=50){
            newScore=newScore-50;
            path =getClass().getResource("..\\sunflowergif.gif").toString();
            plantChooser=0;
            PSC.setsunfllowrList(2,colIndex,rowIndex);
        }
        if (plantChooser==3 && newScore>=50){
            newScore=newScore-50;

            plantChooser=0;
            PSC.bomb(2,colIndex,rowIndex);
        }
        score.setText("score:"+String.valueOf(newScore));

    }
    public void starttimeline(){
        PSC.setanchorpane(mediumanchorpane);
        PSC.setgridpane(StageGridPane);
        PSC.startZombiestimeline();
        PSC.setgamelevel(2);
        PSC.setLabel(score);

    }
    public void setplayersfilename(String a){
        filename=a;
    }
}
