package sample;
import java.io.IOException;
import java.io.File;
import java.io.FileWriter;
import java.util.Date;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CreateAccountController {


    public Label hello_label;
    public TextField player_name;
    public TextField plyer_password;
    public Label showResult_label;


    public void onaction_perviouspage(ActionEvent actionEvent)  throws IOException {
        Stage primaryStage = (Stage) hello_label.getScene().getWindow();
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("plants vs zombies");
        primaryStage.setScene(new Scene(root, 1160, 660));
        primaryStage.show();

    }

    public void submit_onclick(ActionEvent actionEvent) {
        String playersfilename =player_name.getText()+plyer_password.getText();

        File fileAliveTest=new File("D:\\computer engineering\\java game\\zombie vs plantz\\"+playersfilename);
        if(fileAliveTest.exists()){
            showResult_label.setText("this info is there please choose another information"); }else{
            FileCreator file=new FileCreator();
            file.create_file(playersfilename);
            showResult_label.setText("thank you.it's correct");
        }}
}
